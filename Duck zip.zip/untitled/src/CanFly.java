public class CanFly implements FlyBehaviour{
    @Override
    public void fly() {
        System.out.println("I am flying😁");
    }


}
