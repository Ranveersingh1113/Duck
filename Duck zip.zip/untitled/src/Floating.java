public class Floating implements SwimBehaviour {

    @Override
    public void swim() {
        System.out.println("I remain afloat.....");
    }
}
