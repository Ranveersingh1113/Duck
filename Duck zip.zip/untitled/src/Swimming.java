public class Swimming implements SwimBehaviour {

    @Override
    public void swim() {
        System.out.println("I can swim");
    }
}

