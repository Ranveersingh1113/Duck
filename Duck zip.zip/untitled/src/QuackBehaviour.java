public interface QuackBehaviour {
    public void quack();
}
